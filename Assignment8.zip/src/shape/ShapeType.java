package shape;

/**
 * The Enum represents the type that a shape can be.
 */
public enum ShapeType {
  Rectangle, Oval
}
